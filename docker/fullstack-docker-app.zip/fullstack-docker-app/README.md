# Full Stack Docker Application

A full-stack application with Node.js/Express frontend and Flask backend, containerized with Docker.

## 📋 Project Structure

```
fullstack-docker-app/
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── server.js
│   ├── package.json
│   └── Dockerfile
├── backend/
│   ├── app.py
│   ├── requirements.txt
│   └── Dockerfile
├── docker-compose.yaml
├── .gitignore
└── README.md
```

## 🚀 Features

- **Frontend**: Node.js with Express serving a student registration form
- **Backend**: Flask API handling form submissions
- **Docker**: Containerized services with Docker Compose
- **Network**: Both services connected via Docker bridge network

## 📦 Prerequisites

- Docker (version 20.10 or higher)
- Docker Compose (version 1.29 or higher)
- Git
- Docker Hub account (for pushing images)

## 🛠️ Local Development Setup

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd fullstack-docker-app
```

### 2. Build and Run with Docker Compose

```bash
docker-compose up --build
```

This will:
- Build both frontend and backend images
- Start both containers
- Connect them on the same network
- Frontend available at: http://localhost:3000
- Backend API available at: http://localhost:5000

### 3. Stop the Services

```bash
docker-compose down
```

## 🐳 Docker Commands

### Build Images Individually

```bash
# Build frontend
cd frontend
docker build -t your-dockerhub-username/nodejs-frontend:latest .

# Build backend
cd ../backend
docker build -t your-dockerhub-username/flask-backend:latest .
```

### Push Images to Docker Hub

```bash
# Login to Docker Hub
docker login

# Push frontend
docker push your-dockerhub-username/nodejs-frontend:latest

# Push backend
docker push your-dockerhub-username/flask-backend:latest
```

### Pull and Run from Docker Hub

```bash
# Pull images
docker pull your-dockerhub-username/nodejs-frontend:latest
docker pull your-dockerhub-username/flask-backend:latest

# Or simply run docker-compose up
docker-compose up
```

## 📝 API Endpoints

### Backend (Flask)

- `GET /` - API status
- `POST /api/submit` - Submit form data
- `GET /api/submissions` - Get all submissions
- `GET /api/submissions/<id>` - Get specific submission

### Frontend (Express)

- `GET /` - Serve registration form
- `POST /submit` - Handle form submission (forwards to backend)

## 🧪 Testing the Application

1. Open http://localhost:3000 in your browser
2. Fill out the student registration form
3. Submit the form
4. Check the backend logs: `docker-compose logs backend`
5. View all submissions: http://localhost:5000/api/submissions

## 📤 Deployment Steps

### Step 1: Tag Your Images

```bash
docker tag nodejs-frontend your-dockerhub-username/nodejs-frontend:v1.0
docker tag flask-backend your-dockerhub-username/flask-backend:v1.0
```

### Step 2: Push to Docker Hub

```bash
docker push your-dockerhub-username/nodejs-frontend:v1.0
docker push your-dockerhub-username/flask-backend:v1.0
```

### Step 3: Push Code to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Full stack Docker application"
git branch -M main
git remote add origin <your-github-repo-url>
git push -u origin main
```

## 🔧 Environment Variables

### Frontend
- `PORT`: Server port (default: 3000)
- `BACKEND_URL`: Backend API URL (default: http://backend:5000)

### Backend
- No environment variables required (runs on port 5000)

## 🐛 Troubleshooting

### Issue: Cannot connect to backend
- Ensure both containers are on the same network
- Check backend container is running: `docker-compose ps`
- View logs: `docker-compose logs backend`

### Issue: Port already in use
- Change ports in docker-compose.yaml
- Or stop conflicting services

### Issue: CORS errors
- CORS is enabled in the Flask backend
- Ensure BACKEND_URL is correctly set

## 📄 License

This project is open source and available under the MIT License.

## 👤 Author

Your Name

## 🤝 Contributing

Contributions, issues, and feature requests are welcome!
