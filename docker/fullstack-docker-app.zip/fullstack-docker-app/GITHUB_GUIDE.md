# GitHub Setup Guide

## 📚 Step-by-Step Guide to Push to GitHub

### Step 1: Create a GitHub Repository

1. Go to https://github.com
2. Click the "+" icon in the top right
3. Select "New repository"
4. Fill in:
   - Repository name: `fullstack-docker-app`
   - Description: "Full stack application with Node.js frontend and Flask backend"
   - Choose Public or Private
   - **Do NOT** initialize with README, .gitignore, or license (we already have these)
5. Click "Create repository"

### Step 2: Initialize Local Git Repository

```bash
# Navigate to your project directory
cd fullstack-docker-app

# Initialize git (if not already done)
git init

# Add all files
git add .

# Check what will be committed (should exclude node_modules, __pycache__, etc.)
git status

# Commit your changes
git commit -m "Initial commit: Full stack Docker application with Node.js and Flask"
```

### Step 3: Connect to GitHub

Replace `YOUR_USERNAME` and `YOUR_REPO` with your actual GitHub username and repository name:

```bash
# Add remote repository
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git

# Verify remote was added
git remote -v

# Rename branch to main (if needed)
git branch -M main
```

### Step 4: Push to GitHub

```bash
# Push to GitHub
git push -u origin main

# Enter your GitHub credentials if prompted
```

### Step 5: Verify on GitHub

1. Go to your repository URL: `https://github.com/YOUR_USERNAME/YOUR_REPO`
2. You should see all your files
3. Verify that `node_modules/`, `__pycache__/`, and `.vscode/` are NOT present

## 🔐 Authentication Options

### Option 1: Personal Access Token (Recommended)

1. Go to GitHub Settings → Developer settings → Personal access tokens → Tokens (classic)
2. Click "Generate new token (classic)"
3. Give it a name: "Docker App Deploy"
4. Select scopes:
   - `repo` (Full control of private repositories)
   - `workflow` (Update GitHub Action workflows)
5. Click "Generate token"
6. **Copy the token immediately** (you won't see it again!)

When pushing, use:
- Username: Your GitHub username
- Password: Your personal access token (not your GitHub password)

### Option 2: SSH Key

```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "your_email@example.com"

# Copy public key
cat ~/.ssh/id_ed25519.pub

# Add to GitHub: Settings → SSH and GPG keys → New SSH key
# Then use SSH URL instead:
git remote set-url origin git@github.com:YOUR_USERNAME/YOUR_REPO.git
```

## 📝 Making Changes and Pushing Updates

```bash
# Make some changes to your files

# Check what changed
git status
git diff

# Add specific files
git add frontend/server.js
git add backend/app.py

# Or add all changes
git add .

# Commit with a descriptive message
git commit -m "Add form validation and error handling"

# Push to GitHub
git push
```

## 🌿 Working with Branches

```bash
# Create and switch to a new branch
git checkout -b feature/add-database

# Make changes and commit
git add .
git commit -m "Add PostgreSQL database integration"

# Push branch to GitHub
git push -u origin feature/add-database

# Switch back to main
git checkout main

# Merge your branch
git merge feature/add-database

# Push merged changes
git push
```

## 🔄 Common Git Commands

```bash
# See commit history
git log --oneline

# See current branch
git branch

# Pull latest changes from GitHub
git pull

# Discard local changes
git checkout -- filename

# Undo last commit (keep changes)
git reset --soft HEAD~1

# Undo last commit (discard changes)
git reset --hard HEAD~1

# See remote repositories
git remote -v

# Remove remote
git remote remove origin
```

## 📦 Verify .gitignore is Working

```bash
# Check what will be committed
git status

# You should NOT see:
# - node_modules/
# - __pycache__/
# - .vscode/
# - .env
# - *.log

# If you accidentally committed these, remove them:
git rm -r --cached node_modules/
git rm -r --cached __pycache__/
git commit -m "Remove ignored files from repository"
git push
```

## 🚀 Complete Setup Script

Here's a complete script to set everything up:

```bash
#!/bin/bash

# Variables - UPDATE THESE
GITHUB_USERNAME="your-github-username"
REPO_NAME="fullstack-docker-app"

# Initialize git
git init

# Add all files
git add .

# First commit
git commit -m "Initial commit: Full stack Docker application"

# Add remote
git remote add origin https://github.com/${GITHUB_USERNAME}/${REPO_NAME}.git

# Rename to main branch
git branch -M main

# Push to GitHub
git push -u origin main

echo "✅ Code pushed to GitHub successfully!"
echo "🌐 Repository URL: https://github.com/${GITHUB_USERNAME}/${REPO_NAME}"
```

Save as `github-setup.sh`, make executable, and run:

```bash
chmod +x github-setup.sh
./github-setup.sh
```

## 🎯 Best Practices

1. **Commit Often**: Make small, focused commits
2. **Write Good Commit Messages**: 
   - Use present tense: "Add feature" not "Added feature"
   - Be descriptive: "Add user authentication" not "Update files"
3. **Use .gitignore**: Always exclude dependencies, build files, and secrets
4. **Never Commit Secrets**: No API keys, passwords, or tokens
5. **Pull Before Push**: Always `git pull` before `git push` to avoid conflicts

## 🐛 Troubleshooting

### Error: Remote origin already exists
```bash
git remote remove origin
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
```

### Error: Permission denied
- Use personal access token instead of password
- Or set up SSH key

### Error: Large files
```bash
# GitHub has a 100MB file size limit
# Use Git LFS for large files or exclude them
git lfs install
git lfs track "*.large_file"
```

### Accidentally committed secrets
```bash
# Remove from history (use with caution)
git filter-branch --force --index-filter \
  "git rm --cached --ignore-unmatch path/to/secret/file" \
  --prune-empty --tag-name-filter cat -- --all

# Then force push
git push origin --force --all
```

## 📊 Check Your Repository

After pushing, verify:
- ✅ All source files are present
- ✅ README.md displays correctly
- ✅ No node_modules/ or __pycache__/
- ✅ .gitignore is working
- ✅ Docker files are present

## 🔗 Clone Your Repository

Test that others can clone:

```bash
# Clone in a new directory
cd /tmp
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO

# Run the application
docker-compose up --build
```

## 🎉 You're Done!

Your code is now on GitHub! Share the repository URL with others:
`https://github.com/YOUR_USERNAME/YOUR_REPO`
