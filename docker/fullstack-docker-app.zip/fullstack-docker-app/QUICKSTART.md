# Quick Start Guide

## 🏃 Quick Start (3 Steps)

### 1. Start the Application
```bash
docker-compose up --build
```

### 2. Access the Application
- Open your browser: http://localhost:3000
- Fill out the registration form
- Submit!

### 3. Stop the Application
```bash
docker-compose down
```

## 🧪 Testing the Application

### Test 1: Form Submission
1. Navigate to http://localhost:3000
2. Fill in all required fields:
   - Full Name: John Doe
   - Email: john@example.com
   - Phone: 1234567890
   - Date of Birth: 2000-01-01
   - Gender: Male
   - Course: Computer Science
   - Address: 123 Main St
3. Click "Submit Registration"
4. You should see a success message

### Test 2: Backend API Directly
```bash
# Test backend health
curl http://localhost:5000/

# Submit data directly to backend
curl -X POST http://localhost:5000/api/submit \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jane Smith",
    "email": "jane@example.com",
    "phone": "9876543210",
    "dob": "1999-05-15",
    "gender": "female",
    "course": "information_technology",
    "address": "456 Oak Avenue"
  }'

# Get all submissions
curl http://localhost:5000/api/submissions
```

### Test 3: Check Logs
```bash
# View frontend logs
docker-compose logs frontend

# View backend logs
docker-compose logs backend

# Follow logs in real-time
docker-compose logs -f
```

## 🔍 Verify Network Connectivity

```bash
# List running containers
docker-compose ps

# Inspect the network
docker network ls
docker network inspect fullstack-docker-app_app-network

# Test connectivity from frontend to backend
docker-compose exec frontend ping backend
```

## 📊 View Container Stats

```bash
docker stats
```

## 🐳 Docker Hub Deployment

### Update docker-compose.yaml to use Docker Hub images:

```yaml
version: '3.8'

services:
  frontend:
    image: your-dockerhub-username/nodejs-frontend:latest
    # ... rest of config

  backend:
    image: your-dockerhub-username/flask-backend:latest
    # ... rest of config
```

### Build and Push:

```bash
# Make sure to update deploy.sh with your Docker Hub username
./deploy.sh
```

## 🔧 Development Tips

### Hot Reload for Frontend (Development)
Modify `docker-compose.yaml`:
```yaml
frontend:
  # ... existing config
  volumes:
    - ./frontend:/app
    - /app/node_modules
  command: npm run dev
```

### Hot Reload for Backend (Development)
Backend already runs with debug=True in development mode.

## 🚨 Common Issues

### Port Already in Use
```bash
# Change ports in docker-compose.yaml
# Or find and kill process using the port
lsof -ti:3000 | xargs kill -9
lsof -ti:5000 | xargs kill -9
```

### Cannot Connect to Backend
- Ensure both containers are running: `docker-compose ps`
- Check network: `docker network inspect fullstack-docker-app_app-network`
- Verify BACKEND_URL environment variable in frontend

### Image Build Failed
```bash
# Clean up and rebuild
docker-compose down -v
docker system prune -a
docker-compose up --build
```

## 📱 API Testing with Postman

Import this collection:

**POST** http://localhost:5000/api/submit
```json
{
  "name": "Test User",
  "email": "test@example.com",
  "phone": "1234567890",
  "dob": "2000-01-01",
  "gender": "male",
  "course": "computer_science",
  "address": "Test Address"
}
```

**GET** http://localhost:5000/api/submissions

**GET** http://localhost:5000/api/submissions/1
