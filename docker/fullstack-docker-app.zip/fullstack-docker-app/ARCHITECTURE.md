# Project Architecture & Documentation

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                     User's Browser                       │
│                    (Port 3000)                           │
└──────────────────────┬──────────────────────────────────┘
                       │
                       │ HTTP Request
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│            Node.js Express Frontend                      │
│              (Container: nodejs-frontend)                │
│                                                          │
│  • Serves static HTML form                              │
│  • Handles form submission                              │
│  • Forwards data to backend                             │
│                                                          │
└──────────────────────┬──────────────────────────────────┘
                       │
                       │ HTTP POST (Docker Network)
                       │
                       ▼
┌─────────────────────────────────────────────────────────┐
│              Flask Backend API                           │
│              (Container: flask-backend)                  │
│                                                          │
│  • Receives form data                                   │
│  • Validates input                                      │
│  • Processes and stores data                            │
│  • Returns JSON response                                │
│                                                          │
└─────────────────────────────────────────────────────────┘
                       │
                       ▼
                ┌──────────────┐
                │   In-Memory   │
                │   Storage     │
                └──────────────┘
```

## 📦 Component Details

### Frontend (Node.js + Express)

**Technology Stack:**
- Node.js 18 (Alpine Linux)
- Express.js 4.18
- Axios for HTTP requests
- Body-parser for form data

**Key Files:**
- `server.js`: Main Express application
- `public/index.html`: Student registration form
- `package.json`: Dependencies and scripts
- `Dockerfile`: Container configuration

**Responsibilities:**
1. Serve the HTML registration form
2. Handle form submissions from the browser
3. Forward data to Flask backend via HTTP
4. Return success/error responses to the browser

**Endpoints:**
- `GET /`: Serves the registration form
- `POST /submit`: Handles form submission

**Environment Variables:**
- `PORT`: Server port (default: 3000)
- `BACKEND_URL`: Flask backend URL (default: http://backend:5000)

### Backend (Flask)

**Technology Stack:**
- Python 3.11 (Slim)
- Flask 3.0
- Flask-CORS for cross-origin requests

**Key Files:**
- `app.py`: Main Flask application
- `requirements.txt`: Python dependencies
- `Dockerfile`: Container configuration

**Responsibilities:**
1. Receive and validate form data
2. Process student registrations
3. Store submissions (currently in-memory)
4. Provide API endpoints for data retrieval

**API Endpoints:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | API health check |
| POST | `/api/submit` | Submit registration form |
| GET | `/api/submissions` | Get all submissions |
| GET | `/api/submissions/<id>` | Get specific submission |

**Data Model:**
```python
{
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "dob": "2000-01-01",
    "gender": "male",
    "course": "computer_science",
    "address": "123 Main St",
    "timestamp": "2026-01-28T10:30:00"
}
```

## 🐳 Docker Configuration

### Network Architecture

Both containers communicate via a Docker bridge network named `app-network`:

```yaml
networks:
  app-network:
    driver: bridge
```

**Benefits:**
- Isolated network for security
- Service discovery by container name
- No external network access required for inter-service communication

### Container Communication

Frontend communicates with backend using the service name:
```javascript
const BACKEND_URL = 'http://backend:5000';
```

Docker's internal DNS resolves `backend` to the Flask container's IP address.

### Port Mapping

- **Frontend**: Host `3000` → Container `3000`
- **Backend**: Host `5000` → Container `5000`

### Volume Considerations

Currently, no volumes are mounted. For production:
- Add volume for database persistence
- Mount logs directory
- Add config files

## 🔄 Data Flow

### Form Submission Flow

```
1. User fills form in browser
   ↓
2. JavaScript captures form data
   ↓
3. POST request to /submit (frontend)
   ↓
4. Express server receives data
   ↓
5. Axios forwards to http://backend:5000/api/submit
   ↓
6. Flask validates and processes data
   ↓
7. Flask stores in memory and returns JSON
   ↓
8. Express forwards response to browser
   ↓
9. Browser displays success/error message
```

## 🔒 Security Considerations

### Current Implementation
- CORS enabled for development
- No authentication/authorization
- In-memory storage (non-persistent)
- No input sanitization beyond validation
- No HTTPS

### Production Recommendations
1. **Add Authentication**: JWT tokens, OAuth
2. **Input Validation**: Sanitize all inputs
3. **Database**: PostgreSQL, MongoDB, etc.
4. **HTTPS**: Use reverse proxy (Nginx)
5. **Rate Limiting**: Prevent abuse
6. **Environment Variables**: Store secrets securely
7. **CORS**: Restrict to specific origins
8. **Logging**: Add request logging and monitoring

## 📊 Scalability

### Current Limitations
- Single container per service
- In-memory storage
- No load balancing
- No caching

### Scaling Options

**Horizontal Scaling:**
```yaml
services:
  frontend:
    deploy:
      replicas: 3
  backend:
    deploy:
      replicas: 3
```

**Add Load Balancer:**
```yaml
nginx:
  image: nginx:alpine
  ports:
    - "80:80"
  depends_on:
    - frontend
```

**Add Database:**
```yaml
postgres:
  image: postgres:15
  environment:
    POSTGRES_DB: registrations
    POSTGRES_USER: app
    POSTGRES_PASSWORD: secret
  volumes:
    - postgres-data:/var/lib/postgresql/data
```

**Add Redis Cache:**
```yaml
redis:
  image: redis:alpine
  ports:
    - "6379:6379"
```

## 🧪 Testing Strategy

### Manual Testing
1. Form validation testing
2. API endpoint testing with curl
3. Network connectivity testing
4. Container health checks

### Automated Testing (Future)
```yaml
# Add to docker-compose.yaml
test:
  build: ./tests
  depends_on:
    - frontend
    - backend
  command: pytest
```

## 📈 Monitoring & Logging

### Current Logging
- Console output from both services
- Docker logs via `docker-compose logs`

### Production Monitoring (Recommendations)
1. **ELK Stack**: Elasticsearch, Logstash, Kibana
2. **Prometheus + Grafana**: Metrics and dashboards
3. **Sentry**: Error tracking
4. **Health Checks**: Add to docker-compose

```yaml
frontend:
  healthcheck:
    test: ["CMD", "curl", "-f", "http://localhost:3000"]
    interval: 30s
    timeout: 10s
    retries: 3
```

## 🚀 Deployment Options

### Local Development
```bash
docker-compose up --build
```

### Docker Hub
```bash
docker-compose -f docker-compose.prod.yaml up
```

### Cloud Platforms
- **AWS ECS**: Elastic Container Service
- **Google Cloud Run**: Serverless containers
- **Azure Container Instances**: Managed containers
- **DigitalOcean App Platform**: PaaS
- **Kubernetes**: Advanced orchestration

## 🔧 Configuration Management

### Environment Variables

**Frontend:**
```env
PORT=3000
BACKEND_URL=http://backend:5000
NODE_ENV=production
```

**Backend:**
```env
FLASK_ENV=production
FLASK_APP=app.py
DATABASE_URL=postgresql://user:pass@db:5432/dbname
```

### Config Files
Create `config.py` for backend:
```python
import os

class Config:
    DEBUG = os.getenv('FLASK_ENV') == 'development'
    DATABASE_URL = os.getenv('DATABASE_URL')
    SECRET_KEY = os.getenv('SECRET_KEY')
```

## 📝 API Documentation

### Swagger/OpenAPI (Future Enhancement)

Install Flask-RESTX:
```python
from flask_restx import Api, Resource

api = Api(app, version='1.0', title='Registration API')

@api.route('/api/submit')
class Submit(Resource):
    @api.doc('submit_form')
    def post(self):
        """Submit registration form"""
        pass
```

## 🔄 CI/CD Pipeline

Current setup includes GitHub Actions for automated Docker builds.

**Pipeline Stages:**
1. Code push to GitHub
2. GitHub Actions triggered
3. Build Docker images
4. Run tests (future)
5. Push to Docker Hub
6. Deploy to production (future)

## 📚 Additional Resources

- **Docker Documentation**: https://docs.docker.com
- **Express.js Guide**: https://expressjs.com
- **Flask Documentation**: https://flask.palletsprojects.com
- **Docker Compose**: https://docs.docker.com/compose
- **GitHub Actions**: https://docs.github.com/actions

## 🎯 Future Enhancements

1. **Database Integration**: PostgreSQL or MongoDB
2. **Authentication**: User login system
3. **File Uploads**: Profile pictures, documents
4. **Email Notifications**: Confirmation emails
5. **Admin Dashboard**: View all submissions
6. **Export Features**: CSV, PDF export
7. **Search & Filter**: Search submissions
8. **Pagination**: Handle large datasets
9. **Websockets**: Real-time updates
10. **Mobile App**: React Native frontend
