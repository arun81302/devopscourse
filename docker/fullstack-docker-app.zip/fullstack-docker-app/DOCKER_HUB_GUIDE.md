# Docker Hub Deployment Guide

## 📦 Prerequisites

1. Docker Hub account (create at https://hub.docker.com)
2. Docker installed and running locally
3. Git installed

## 🔐 Step 1: Login to Docker Hub

```bash
docker login
# Enter your Docker Hub username and password
```

## 🏗️ Step 2: Build Images

### Build with your Docker Hub username:

```bash
# Replace YOUR_USERNAME with your actual Docker Hub username
export DOCKER_USERNAME=YOUR_USERNAME

# Build frontend
docker build -t ${DOCKER_USERNAME}/nodejs-frontend:latest ./frontend
docker build -t ${DOCKER_USERNAME}/nodejs-frontend:v1.0 ./frontend

# Build backend
docker build -t ${DOCKER_USERNAME}/flask-backend:latest ./backend
docker build -t ${DOCKER_USERNAME}/flask-backend:v1.0 ./backend
```

## ⬆️ Step 3: Push to Docker Hub

```bash
# Push frontend
docker push ${DOCKER_USERNAME}/nodejs-frontend:latest
docker push ${DOCKER_USERNAME}/nodejs-frontend:v1.0

# Push backend
docker push ${DOCKER_USERNAME}/flask-backend:latest
docker push ${DOCKER_USERNAME}/flask-backend:v1.0
```

## ✅ Step 4: Verify on Docker Hub

1. Go to https://hub.docker.com
2. Login to your account
3. You should see two new repositories:
   - `YOUR_USERNAME/nodejs-frontend`
   - `YOUR_USERNAME/flask-backend`

## 🚀 Step 5: Pull and Run from Docker Hub

Anyone can now pull and run your images:

```bash
# Pull images
docker pull YOUR_USERNAME/nodejs-frontend:latest
docker pull YOUR_USERNAME/flask-backend:latest

# Run with docker-compose (update docker-compose.yaml first)
docker-compose up
```

## 📝 Step 6: Update docker-compose.yaml

Update your `docker-compose.yaml` to use Docker Hub images:

```yaml
version: '3.8'

services:
  frontend:
    image: YOUR_USERNAME/nodejs-frontend:latest  # Changed from build: ./frontend
    container_name: nodejs-frontend
    ports:
      - "3000:3000"
    environment:
      - BACKEND_URL=http://backend:5000
    depends_on:
      - backend
    networks:
      - app-network
    restart: unless-stopped

  backend:
    image: YOUR_USERNAME/flask-backend:latest  # Changed from build: ./backend
    container_name: flask-backend
    ports:
      - "5000:5000"
    networks:
      - app-network
    restart: unless-stopped

networks:
  app-network:
    driver: bridge
```

## 🔄 Automated Deployment with Script

Use the provided deployment script:

```bash
# Edit deploy.sh and update DOCKER_USERNAME
nano deploy.sh

# Run the script
chmod +x deploy.sh
./deploy.sh
```

## 🤖 GitHub Actions (Optional)

Set up automatic deployment on push to GitHub:

1. Go to your GitHub repository settings
2. Navigate to Secrets and Variables → Actions
3. Add these secrets:
   - `DOCKER_USERNAME`: Your Docker Hub username
   - `DOCKER_PASSWORD`: Your Docker Hub password/token

The workflow in `.github/workflows/docker-build.yml` will automatically:
- Build images on every push to main/develop
- Push to Docker Hub
- Tag with both `latest` and commit SHA

## 🏷️ Image Tagging Strategy

- `latest`: Always points to the most recent build
- `v1.0`, `v1.1`: Version tags for releases
- `<commit-sha>`: Specific commit versions (with GitHub Actions)

```bash
# Tag specific version
docker tag ${DOCKER_USERNAME}/nodejs-frontend:latest ${DOCKER_USERNAME}/nodejs-frontend:v1.1
docker push ${DOCKER_USERNAME}/nodejs-frontend:v1.1
```

## 📊 Check Your Images

```bash
# List local images
docker images | grep ${DOCKER_USERNAME}

# Pull and verify
docker pull ${DOCKER_USERNAME}/nodejs-frontend:latest
docker pull ${DOCKER_USERNAME}/flask-backend:latest

# Run single container
docker run -p 3000:3000 ${DOCKER_USERNAME}/nodejs-frontend:latest
```

## 🔧 Troubleshooting

### Authentication Failed
```bash
# Logout and login again
docker logout
docker login
```

### Image Too Large
```bash
# Check image size
docker images

# Optimize Dockerfile (use alpine images, multi-stage builds)
# Clean up unnecessary files in .dockerignore
```

### Push Denied
- Ensure repository name matches your Docker Hub username
- Check if repository is public or private
- Verify you have push permissions

## 🌐 Making Images Public

1. Go to Docker Hub
2. Navigate to your repository
3. Settings → Make Public

Now anyone can pull your images without authentication!

## 📱 Share Your Images

Your images are now available at:
- `docker pull YOUR_USERNAME/nodejs-frontend:latest`
- `docker pull YOUR_USERNAME/flask-backend:latest`

Share these commands with others or add them to your README!
